<?php
    setcookie('em',"", time()-10000);
    header("Location:login.php");
?>