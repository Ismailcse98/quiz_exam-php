<div class="main-section">
    <div class="container">
        <div class="row">
            <div class="col-md-3">
                <div class="dashboard-list">
                    <ul>
                        <li><a href="index.php">Add Student</a></li>
                        <li><a href="all_student.php">Student List</a></li>
                        <li><a href="add_chapter.php">Add Chapter</a></li>
                        <li><a href="all_chapter.php">Chapter List</a></li>
                        <li><a href="result.php">Results List</a></li>
                        <li><a href="logout.php">Logout</a></li>
                    </ul>
                 </div>
            </div>